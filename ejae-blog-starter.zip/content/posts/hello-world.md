---
title: "Why I'm Writing About Antibodies"
date: 2026-11-12
tags: ["intro", "antibody"]
summary: "What this blog will cover, and how I approach each topic."
draft: false
ShowToc: false
---

Antibody therapeutics have moved far beyond the classic monoclonal IgG. Bispecifics, antibody–drug conjugates, and brain-penetrant formats now make up a large share of clinical pipelines, and AI is starting to change how these molecules are designed.

This blog is where I organize what I learn. Each post will:

1. **Start from the mechanism** — what the molecule does at the target, cell, and tissue level.
2. **Follow the evidence** — preclinical models, clinical readouts, and where they disagree.
3. **End with open questions** — what is still unknown or contested.

A quick example of how equations will look, for binding affinity:

$$
K_D = \frac{k_{\text{off}}}{k_{\text{on}}}
$$

All content is based on published papers and public disclosures, with references at the end of each post.

*(Edit or delete this sample post once your first real post is up.)*
