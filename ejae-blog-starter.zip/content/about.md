---
title: "About"
url: "/about/"
ShowToc: false
ShowReadingTime: false
ShowShareButtons: false
---

I'm **Ejae Kim**, a pharmaceutical R&D scientist specializing in **drug mechanism of action (MOA)** and **efficacy validation**, with a research focus on liver and lung disease.

## What this blog is about

Long-form, literature-based notes on:

- Antibody therapeutics — formats, mechanisms, and clinical evidence
- Emerging modalities and delivery strategies
- AI-driven approaches to drug discovery

Every post cites its sources. Views are my own and are based only on publicly available information.

## Background

- **Ph.D. & M.S.**, Seoul National University — molecular microbiology (stress response and transcriptional regulation)

## Contact

- [LinkedIn](https://www.linkedin.com/in/YOUR-LINKEDIN-ID)
- [GitHub](https://github.com/ejae-kim)
